import i_fun


def Add():
    i_fun.he()
    while 1:    
        i_fun.Nav()
        if i_fun.i=='1':
            i_fun.ge()
    
        elif i_fun.i=='2':
            i_fun.ban()
    

        elif i_fun.i=='3':
            i_fun.st()

        elif i_fun.i=='4':
            i_fun.oe()
 
        elif i_fun.i=='5':
            i_fun.jh()
        else:
            i_fun.cur.close()
            i_fun.conn.close()       
            break



